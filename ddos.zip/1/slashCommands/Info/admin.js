const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'admin',
    description: 'Admin Info',
    type: 'CHAT_INPUT',
    run: async (client, interaction) => {
        const embed = new MessageEmbed()
            .setTitle(`\`${client.user.username}'s admin\``)
            .setDescription(`\`\`\`ini\n[ 🔽 Name : xxxxx ]\n\`\`\`
                             \`\`\`ini\n[ 💍 Age : xxxx ]\n\`\`\`                                               
                             \`\`\`ini\n[ 📱 Phone : xxxx ]\n\`\`\`
                             \`\`\`ini\n[ 💒 City : xxxx ]\n\`\`\`
                             \`\`\`ini\n[ 👉 Hobbies : xxxx]\n\`\`\`
                             \`\`\`ini\n[ 💚 Crush Name : LHg ]\n\`\`\`
                             \`\`\`ini\n[ 🔗 Facebook  : https://www.facebook.com/katavn.2006 ]\n\`\`\`
                             \`\`\`ini\n[ 📌 Github  : https://github.com/katavnnn ]\n\`\`\`
                             \`\`\`ini\n[ 🎧 Music  : xxxx ]\n\`\`\`



`)
            .setColor("RANDOM")
            .setFooter({ text: "© » katavnnn#1774" })
            .setTimestamp()
        interaction.reply({ embeds: [embed] });
    },
};