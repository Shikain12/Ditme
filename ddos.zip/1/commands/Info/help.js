module.exports = {
    name: 'help', 
    category: 'info',
    aliases: ['p'],
    run: (client, message, args) => {
        message.reply("**Layer7**\n`If you need help, contact katavnnn#1774(fee)`\n`or use your head`");
    }
}